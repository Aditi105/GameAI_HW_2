"make" command compiles all files
"./part1" runs the part1 files
"./part2a" runs the part2a file and so on for all the files.

all the part a files contain the parameters that are not pleasing or incorrect, and the part b files contain the fixed parameters which have a more pleasing implementation.


References:
SFML libraries from the website.

Chatgpt to help with concept understanding and error fixing.

